using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CoinEnum
{
    small = 0,
    medium = 1,
    large = 2,
}
