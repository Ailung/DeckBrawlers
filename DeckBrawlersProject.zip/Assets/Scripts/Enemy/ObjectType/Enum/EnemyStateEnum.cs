using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EnemyStateEnum
{
    chasing = 0,
    waiting = 1,
    casting = 2,
}
