using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum AppearanceEnum
{
    hat = 0,
    skin = 1,
    face = 2,
    shape = 3,
    top = 4,
    bottom = 5,
    hands = 6,
    shoes = 7,
}
