using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SpellScriptableBehaviourClass : ScriptableObject
{
    public abstract void Behaviour(GameObject caster);

}
